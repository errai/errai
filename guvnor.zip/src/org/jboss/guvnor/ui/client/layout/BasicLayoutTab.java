package org.jboss.guvnor.ui.client.layout;

import com.google.gwt.user.client.ui.*;


public class BasicLayoutTab extends Composite {
    String name;

    public BasicLayoutTab(BasicLayout bl, Widget widgetRef, Image tabIcon, String tabName) {
        super();
        this.name = tabName;

        HorizontalPanel hPanel = new HorizontalPanel();
        initWidget(hPanel);
        hPanel.add(tabIcon);

        HTML tabNameWidget = new HTML(tabName);
        tabNameWidget.setStylePrimaryName("guvnor-TabLabelText");

        hPanel.add(tabNameWidget);

        Image closeButton = new Image("images/close-icon.gif");
        closeButton.addClickListener(new BasicLayoutTabCloseListener(widgetRef, bl));
        hPanel.add(closeButton);
        
    }
}

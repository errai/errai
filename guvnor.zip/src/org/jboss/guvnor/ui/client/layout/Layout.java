package org.jboss.guvnor.ui.client.layout;

import com.google.gwt.user.client.ui.Panel;


public interface Layout {
    public Panel createLayout();
}

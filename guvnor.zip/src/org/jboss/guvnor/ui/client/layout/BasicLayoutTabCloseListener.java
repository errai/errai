package org.jboss.guvnor.ui.client.layout;

import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;

/**
 * Created by IntelliJ IDEA.
 * User: christopherbrock
 * Date: May 16, 2008
 * Time: 5:44:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class BasicLayoutTabCloseListener implements ClickListener {
    private Widget widget;
    private BasicLayout basicLayout;

    public BasicLayoutTabCloseListener(Widget widget, BasicLayout basicLayout) {
        this.widget = widget;
        this.basicLayout = basicLayout;
    }

    public void onClick(Widget sender) {
        basicLayout.closeTab(widget);
    }
}

package org.jboss.guvnor.ui.client.layout;

import com.google.gwt.user.client.ui.*;
import org.jboss.guvnor.ui.client.ToolSet;


public class BasicLayout implements Layout {
    DockPanel rootPanel = new DockPanel();

    public HorizontalPanel header = new HorizontalPanel();
    public StackPanel navigation = new StackPanel();
    public FlowPanel appArea = new FlowPanel();

    public TabPanel tab = new TabPanel();
    public FlowPanel appPanel = new FlowPanel();


    public int tabs = 0;

    public Panel createLayout() {
        rootPanel.setWidth("100%");
        rootPanel.setHeight("100%");

        rootPanel.add(header(), DockPanel.NORTH);
        rootPanel.setCellHeight(header, "100px");

        tab.setSize("100%", "100%");
        appPanel.add(tab);
        rootPanel.add(appPanel, DockPanel.EAST);
        rootPanel.setCellWidth(appPanel, "74%");
        rootPanel.setCellHorizontalAlignment(appPanel, HasHorizontalAlignment.ALIGN_LEFT);
        rootPanel.setCellVerticalAlignment(appPanel, HasVerticalAlignment.ALIGN_TOP);

        rootPanel.add(navigation(), DockPanel.WEST);
        rootPanel.setCellWidth(navigation, "25%");
        rootPanel.setCellHorizontalAlignment(navigation, HasHorizontalAlignment.ALIGN_LEFT);
        rootPanel.setCellVerticalAlignment(navigation, HasVerticalAlignment.ALIGN_TOP);

        return rootPanel;
    }

    public HorizontalPanel header() {
        header.add(new Image("images/guvnorlogo.jpg"));

        header.setHeight("100px");
        header.setWidth("100%");
        header.setStyleName("headerStyle");

        return header;
    }

    public StackPanel navigation() {
        navigation.setWidth("100%");
        return navigation;
    }


    public void addToolSet(ToolSet toolSet) {
        navigation.add(toolSet.getWidget(), toolSet.getToolSetName());
    }

    public void openTab(Widget widget, String name) {
        FlowPanel flowpanel;
        flowpanel = new FlowPanel();
        flowpanel.add(widget);
        tab.add(flowpanel, new BasicLayoutTab(this, flowpanel, new Image("images/default-icon.gif"), name));
        tab.selectTab(tabs++);
    }

    public void closeTab(Widget widget) {
        int idx = tab.getWidgetIndex(widget);
        if (idx != 0) idx--;
        tab.remove(widget);
        tab.selectTab(idx);
    }

}

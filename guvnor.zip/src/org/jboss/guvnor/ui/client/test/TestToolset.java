package org.jboss.guvnor.ui.client.test;

import org.jboss.guvnor.ui.client.ToolSet;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.user.client.ui.HTML;

/**
 * Created by IntelliJ IDEA.
* User: christopherbrock
* Date: May 16, 2008
* Time: 6:29:38 PM
* To change this template use File | Settings | File Templates.
*/
public class TestToolset implements ToolSet {
    private String toolSetName;
    private String toolArea;

    public TestToolset(String toolSetName, String toolArea) {
        this.toolSetName = toolSetName;
        this.toolArea = toolArea;
    }

    public String getToolSetName() {
        return toolSetName;
    }

    public Widget getWidget() {
        return new HTML(toolArea);
    }
}

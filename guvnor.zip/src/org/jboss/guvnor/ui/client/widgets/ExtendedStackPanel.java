package org.jboss.guvnor.ui.client.widgets;

import com.google.gwt.user.client.ui.StackPanel;

public class ExtendedStackPanel extends StackPanel {
    public ExtendedStackPanel() {
        super();    //To change body of overridden methods use File | Settings | File Templates.
    }
}

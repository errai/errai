package org.jboss.guvnor.ui.client.builtin.toolsets;

import org.jboss.guvnor.ui.client.ToolSet;
import org.jboss.guvnor.ui.client.GuvnorCoreClient;
import org.jboss.guvnor.ui.client.listeners.TabOpeningClickListener;
import com.google.gwt.user.client.ui.*;


public class AboutToolSet implements ToolSet {
    public String getToolSetName() {
        return "About";
    }

    public Widget getWidget() {
        VerticalPanel vp = new VerticalPanel();

        Image jbossLogo = new Image("images/jbosslogo.jpg");
        HTML name = new HTML("<h2>JBoss Guvnor UI for Tooling Platform</h2>");
        HTML version = new HTML("<h3>Version 0.01 Super-Pre-Alpha</h3>");

        vp.add(jbossLogo);
        vp.add(name);
        vp.add(version);

        vp.setWidth("100%");
        vp.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
        vp.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
        vp.setStyleName("guvnor-SimpleOutlineArea");

        vp.setCellVerticalAlignment(jbossLogo, HasVerticalAlignment.ALIGN_MIDDLE);
        vp.setCellVerticalAlignment(name, HasVerticalAlignment.ALIGN_MIDDLE);
        vp.setCellVerticalAlignment(version, HasVerticalAlignment.ALIGN_MIDDLE);


        PushButton button = new PushButton("About Guvnor");
        button.addClickListener(new TabOpeningClickListener("About", vp));
        return button;
    }
}

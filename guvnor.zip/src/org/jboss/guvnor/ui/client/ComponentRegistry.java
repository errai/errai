package org.jboss.guvnor.ui.client;

import java.util.Map;
import java.util.HashMap;

public class ComponentRegistry {


}

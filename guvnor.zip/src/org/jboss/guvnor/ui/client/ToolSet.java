package org.jboss.guvnor.ui.client;

import com.google.gwt.user.client.ui.Widget;

import java.util.List;

public interface ToolSet {
    public String getToolSetName();

    public Widget getWidget();
}

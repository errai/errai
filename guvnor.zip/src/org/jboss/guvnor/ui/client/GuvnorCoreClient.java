package org.jboss.guvnor.ui.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.*;
import org.jboss.guvnor.ui.client.layout.BasicLayout;
import org.jboss.guvnor.ui.client.test.TestToolset;
import org.jboss.guvnor.ui.client.builtin.toolsets.AboutToolSet;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class GuvnorCoreClient implements EntryPoint {
    public static final BasicLayout layout = new BasicLayout();

    /**
     * This is the entry point method.
     */
    public void onModuleLoad() {
        RootPanel.get("rootPanel").add(layout.createLayout());

        /**
         * Link in tooling components.
         */
        layout.addToolSet(new AboutToolSet());
        layout.addToolSet(new TestToolset("Test Toolset 1", "Lorem Ipsum."));
        layout.addToolSet(new TestToolset("Test Toolset 2", "Lorem Ipsum2."));
    }
}

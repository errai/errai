package org.jboss.guvnor.ui.client.listeners;

import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;
import org.jboss.guvnor.ui.client.GuvnorCoreClient;

public class TabOpeningClickListener implements ClickListener {
    private String tabName;
    private Widget panelWidget;

    public TabOpeningClickListener(String tabName, Widget panelWidget) {
        this.tabName = tabName;
        this.panelWidget = panelWidget;
    }

    public void onClick(Widget sender) {
        GuvnorCoreClient.layout.openTab(panelWidget, tabName);
    }
}
